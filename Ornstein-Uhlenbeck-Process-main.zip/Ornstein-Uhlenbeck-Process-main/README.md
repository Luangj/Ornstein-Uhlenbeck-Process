# Ornstein-Uhlenbeck-Process
This is for my Programme Level Assessment (PLA), I have created a project as apart of my MSci Financial Mathematics course, applying first order linear ODEs to real world applications - Ornstein-Uhlenbeck process 
